
import { h, render } from 'preact';

import Popup from './Popup/index.js';

render(<Popup/>, document.getElementById('app'))

